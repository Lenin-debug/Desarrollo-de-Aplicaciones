/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.*;
import Vista.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.util.List;

public class ControladorEstudiante {

    private EstudianteVista vista;
    private BaseDatosSimulada baseDatos;
    private Usuario usuario;

    public ControladorEstudiante(EstudianteVista vista, BaseDatosSimulada baseDatos) {
    this.vista = vista;
    this.baseDatos = baseDatos;
    this.usuario = vista.getUsuario();
    this.vista.agregarAgregarListener(new ListenerAgregar());
    this.vista.agregarCompletarListener(new ListenerCompletar());
    this.vista.agregarEliminarListener(new ListenerEliminar());
    this.vista.agregarCalcularListener(new ListenerCalcular());
    this.vista.agregarSalirListener(new ListenerSalir());
    
    vista.actualizarTabla(BaseDatosSimulada.obtenerTareas());
}

 private void mostrarTareasEstudiante() {
        List<Tarea> todas = baseDatos.getTareas();
        List<Tarea> propias = new ArrayList<>();

        for (Tarea t : todas) {
            if (t.getNombreEstudiante().equals(usuario.getNombreUsuario())) {
                propias.add(t);
            }
        }

        vista.actualizarTabla(propias);
    }
    // ---------------------- LISTENERS ----------------------

    // Agregar tarea
    class ListenerAgregar implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            String nombre = vista.getNombre();
            String descripcion = vista.getDescripcion();
            String fecha = vista.getFecha();
            String estado = vista.getEstado();

            if (nombre.isEmpty() || descripcion.isEmpty() || fecha.isEmpty()) {
                vista.mostrarMensaje("Por favor complete todos los campos.");
                return;
            }

            Tarea nueva = new Tarea(usuario.getNombreUsuario(), nombre, descripcion, fecha, estado);
            BaseDatosSimulada.agregarTarea(nueva);

            vista.mostrarMensaje("✅ Tarea agregada correctamente.");
            vista.limpiarCampos();
            vista.actualizarTabla(BaseDatosSimulada.obtenerTareas());
        }
    }

    // Marcar como completada
    class ListenerCompletar implements ActionListener {
        @Override
         public void actionPerformed(ActionEvent e) {
            String nombreTarea = vista.getTareaSeleccionada();
            if (nombreTarea == null) {
                vista.mostrarMensaje("Seleccione una tarea de la tabla para completarla.");
                return;
            }

            boolean resultado = BaseDatosSimulada.marcarComoCompletada(nombreTarea);
            if (resultado) {
                vista.mostrarMensaje("✅ Tarea marcada como completada.");
            } else {
                vista.mostrarMensaje("❌ No se encontró la tarea seleccionada.");
            }

            vista.actualizarTabla(BaseDatosSimulada.obtenerTareas());
        }
    }

    // Eliminar tarea
    class ListenerEliminar implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String nombreTarea = vista.getTareaSeleccionada();
            if (nombreTarea == null) {
                vista.mostrarMensaje("Seleccione una tarea de la tabla para eliminarla.");
                return;
            }

            int confirm = javax.swing.JOptionPane.showConfirmDialog(null,
                    "¿Está seguro de eliminar la tarea '" + nombreTarea + "'?",
                    "Confirmar eliminación", javax.swing.JOptionPane.YES_NO_OPTION);

            if (confirm == javax.swing.JOptionPane.YES_OPTION) {
                boolean resultado = BaseDatosSimulada.eliminarTarea(nombreTarea);
                if (resultado) {
                    vista.mostrarMensaje("🗑️ Tarea eliminada correctamente.");
                } else {
                    vista.mostrarMensaje("❌ No se encontró la tarea.");
                }

                vista.actualizarTabla(BaseDatosSimulada.obtenerTareas());
            }
        }
    }

    // Calcular avance
    class ListenerCalcular implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            List<Tarea> tareas = BaseDatosSimulada.obtenerTareas();
            int total = tareas.size();
            long pendientes = tareas.stream().filter(t -> t.getEstado().equalsIgnoreCase("Pendiente")).count();
            long enProceso = tareas.stream().filter(t -> t.getEstado().equalsIgnoreCase("En Proceso")).count();
            long completadas = tareas.stream().filter(t -> t.getEstado().equalsIgnoreCase("Completada")).count();

            String mensaje = "📊 RESUMEN DE TAREAS:\n\n" +
                    "Total: " + total + "\n" +
                    "Pendientes: " + pendientes + "\n" +
                    "En proceso: " + enProceso + "\n" +
                    "Completadas: " + completadas;

            vista.mostrarMensaje(mensaje);
        }
    }

    // Cerrar sesión
    class ListenerSalir implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            vista.dispose();
            Login loginVista = new Login();
            new ControladorLogin(loginVista, baseDatos);
            loginVista.setVisible(true);
        }
    }
}