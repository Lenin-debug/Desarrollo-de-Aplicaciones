/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author User
 */
public class Tarea {

    // ------------------ ATRIBUTOS ------------------
    
    private String nombreEstudiante; // 👈 NUEVO
    private String nombre;
    private String descripcion;
    private String fechaEntrega;
    private String estado;

    public Tarea(String nombreEstudiante, String nombre, String descripcion, String fechaEntrega, String estado) {
        this.nombreEstudiante = nombreEstudiante;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.fechaEntrega = fechaEntrega;
        this.estado = estado;
    }

    // Getters y Setters
    public String getNombreEstudiante() {
        return nombreEstudiante;
    }

    public void setNombreEstudiante(String nombreEstudiante) {
        this.nombreEstudiante = nombreEstudiante;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getFechaEntrega() {
        return fechaEntrega;
    }

    public void setFechaEntrega(String fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "Estudiante: " + nombreEstudiante + "\n" +
               "Tarea: " + nombre + "\n" +
               "Descripción: " + descripcion + "\n" +
               "Fecha: " + fechaEntrega + "\n" +
               "Estado: " + estado + "\n";
    }
}